LABEL_V_VARS = "v"
LABEL_L_VARS = "l"
LABEL_R_VARS = "r"
LABEL_P_VARS = "p"
LABEL_A_VARS = "a"
LABEL_U_VARS = "u"
LABEL_D_ZERO_VARS = "d0"
LABEL_D_ONE_VARS = "d1"
LABEL_C_VARS = "c"

# add for blocking literal
LABEL_B_VARS = "b"

# add for node_index-height relation literal
LABEL_H_VARS = "h"

# add for indicating atleast use how many nodes
LABEL_M_VARS = "m"

LABEL_T_VARS = "t"

# add for the literal used for constraints \lor l_i = 1
LABEL_Y_VARS = "y"

# add for the transforming the l_ij and r_ij and p_ji
LABEL_X_VARS = "x"

LABEL_LAMBDA_VARS = "lambda"
LABEL_TAU_VARS = "tau"
LABEL_TRUE_VARS = "true"
LABEL_FALSE_VARS = "false"

LABEL_PREFIX_RES = "rs_"
LABEL_PREFIX_FEATS = "at_"
LABEL_PREFIX_DUMMY = "dum_"
LABEL_PREFIX_RES = "res"


LABEL_SUFFIX_DATA = "data"
LABEL_SUFFIX_NAMES = "names"
LABEL_SUFFIX_RESULTS = "result"

LABEL_SUFFIX_REDUCED_CSV = "-reduced.csv"
LABEL_SUFFIX_DIR_RESULTS = "Results"
LABEL_SUFFIX_SAVE_RESULTS = "_save"
LABEL_SUFFIX_UNARY_EXT_CSV = "-un-extra.csv"
LABEL_SUFFIX_UNARY_CSV = "-un.csv"


PRINT_TREE_SIZE_RESULTS  = "Tree of size"
PRINT_OPT_TREE_SIZE_RESULTS  = "Optimal tree" 
PRINT_COUNTER_RESULTS  = "Counter" 


